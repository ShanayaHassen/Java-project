package pas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	
	Connection conn = null;
	Connection conn2 = null;

	public Connection createConnection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PAS","root","Gnei$810#");
			System.out.println("Connection established");
		}
		catch(SQLException e) {
			System.out.println("Connection Failed");
		}
		return conn;
	}
	
	public Connection createConnection2() {
		try {
			conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/Citizen","root","Gnei$810#");
			System.out.println("Connection established");	
		}
		catch(SQLException e) {
			System.out.println("Connection Failed");
		}
		return conn2;
	}
}
