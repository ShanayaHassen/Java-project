package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminPanel extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTextField txtnic;
	private JTextField txtstatus;
	DefaultTableModel model;
	Connection conn;
	private JTable table_2;
	private JTextField txtnic_1;
	private JTextField txtappdate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPanel frame = new AdminPanel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminPanel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(5, 100, 1350, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 36, 1320, 125);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);

		
		JButton btnload = new JButton("Load");
		btnload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DatabaseConnection dbCon = new DatabaseConnection();
				Connection conn = dbCon.createConnection();
				try {
					String sql = "SELECT * FROM Applicant";
					Statement stmt = conn.createStatement();
				
					ResultSet result = stmt.executeQuery(sql);
					ResultSetMetaData rsmd = result.getMetaData();
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					
					int cols = rsmd.getColumnCount();
					String[] colName = new String [cols];
					
					
					for(int i=0; i<cols;i++)
						colName[i] = rsmd.getColumnName(i+1);
					
					model.setColumnIdentifiers(colName);
					
					String NIC, FirstName, LastName, Email, Contact, Gender, aplDOB, Address, Docs, Status;
					
					while (result.next()) {
						NIC = result.getString(1);
						FirstName = result.getString(2);
						LastName = result.getString(3);
						Email  = result.getString(4);
						Contact = result.getString(5);
						Gender = result.getString(6);
						aplDOB = result.getString(7);
						Address = result.getString(8);
						Docs = result.getString(9);
						Status = result.getString(10);
						
						String row[] = {NIC, FirstName, LastName, Email, Contact, Gender, aplDOB, Address, Docs, Status};
						model.addRow(row);
					}
					stmt.close();
					conn.close();	
				}
				catch(SQLException ex) {
					System.out.println(ex.getMessage());
				}	
			}
		});
		btnload.setBounds(570, 186, 89, 23);
		contentPane.add(btnload);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				table.setModel(new DefaultTableModel());
			}
		});
		btnclear.setBounds(670, 186, 89, 23);
		contentPane.add(btnclear);
		
		JButton btnupdate = new JButton("Update");
		btnupdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtnic.getText();
				String status = txtstatus.getText();
				
				Admin ad = new Admin();
				ad.updateStatus(nic, status);
				
				int i = table_1.getSelectedRow();
				if (i>=0) {
					model.setValueAt(txtnic.getText(), i, 0);
					model.setValueAt(txtstatus.getText(), i, 1);
				}
			}
		});
		btnupdate.setBounds(120, 350, 89, 23);
		contentPane.add(btnupdate);
		
		JButton btnsave = new JButton("View");
		btnsave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DatabaseConnection dbCon = new DatabaseConnection();
				Connection conn = dbCon.createConnection();
				
				DefaultTableModel model = new DefaultTableModel();
			    try {
			        String sql = "SELECT * FROM ApplicantStatus"; 
			        PreparedStatement pstmt = conn.prepareStatement(sql);
			        ResultSet rs = pstmt.executeQuery();

			        // Get metadata about the ResultSet (columns)
			        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
			        int columnCount = metaData.getColumnCount();

			        // Add columns to the table model
			        for (int column = 1; column <= columnCount; column++) {
			            model.addColumn(metaData.getColumnLabel(column));
			        }

			        // Add rows to the table model
			        while (rs.next()) {
			            Object[] row = new Object[columnCount];
			            for (int i = 0; i < columnCount; i++) {
			                row[i] = rs.getObject(i + 1);
			            }
			            model.addRow(row);
			        }
			
			        rs.close();
			        pstmt.close();
			        conn.close();

			        // Set the model to the table
			       table_1.setModel(model);
			    
			  } 
			    catch (SQLException ex) {
			        ex.printStackTrace();	
			    }
			}
		});
		btnsave.setBounds(230, 350, 89, 23);
		contentPane.add(btnsave);
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		scrollPane_1.setBounds(10, 240, 300, 100);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		model = new DefaultTableModel();
		Object[] column = {"Applicant NIC","Application Status"};
		final Object[] row = new Object [2];
		model.setColumnIdentifiers(column);
		scrollPane_1.setViewportView(table_1);
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				int i = table_1.getSelectedRow();
				if(i>=0) {
					txtnic.setText(model.getValueAt(i,0).toString());
					txtstatus.setText(model.getValueAt(i,1).toString());	
				}	
			}
		});
		table_1.setModel(model);
		
		JLabel lblnic = new JLabel("NIC");
		lblnic.setBounds(348, 250, 46, 14);
		contentPane.add(lblnic);
		
		JLabel lblstatus = new JLabel("Status");
		lblstatus.setBounds(348, 283, 46, 14);
		contentPane.add(lblstatus);
		
		txtnic = new JTextField();
		txtnic.setBounds(427, 250, 130, 20);
		contentPane.add(txtnic);
		txtnic.setColumns(10);
		
		txtstatus = new JTextField();
		txtstatus.setBounds(427, 279, 130, 20);
		contentPane.add(txtstatus);
		txtstatus.setColumns(10);
		
		JButton btnAdd = new JButton("Insert");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				String nic = txtnic.getText();
				String status = txtstatus.getText();
				
				if(txtnic.getText().equals("") || txtstatus.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill all fields");
				}
				else {
					row[0] = txtnic.getText();
					row[1] = txtstatus.getText();
					
					model.addRow(row);

					Admin ad = new Admin();
					ad.insertStatus(nic, status);
					
					txtnic.setText("");
					txtstatus.setText("");
				}	
			}
		});
		btnAdd.setBounds(20, 350, 89, 23);
		contentPane.add(btnAdd);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		scrollPane_2.setBounds(614, 241, 300, 100);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = table_2.getSelectedRow();
				if(i>=0) {
					txtnic_1.setText(model.getValueAt(i,0).toString());
					txtappdate.setText(model.getValueAt(i,1).toString());	
				}
			}
		});
		table_2.setModel(model);
		
		model = new DefaultTableModel();
		Object[] column1 = {"Applicant NIC","Appointment Date"};
		final Object[] row1 = new Object [2];
		model.setColumnIdentifiers(column1);
		scrollPane_2.setViewportView(table_2);
		
		JLabel lblnic_1 = new JLabel("NIC");
		lblnic_1.setBounds(950, 255, 46, 14);
		contentPane.add(lblnic_1);
		
		JLabel lblAppointmentData = new JLabel("Appointment Date");
		lblAppointmentData.setBounds(950, 283, 120, 14);
		contentPane.add(lblAppointmentData);
		
		txtnic_1 = new JTextField();
		txtnic_1.setColumns(10);
		txtnic_1.setBounds(1060, 250, 170, 20);
		contentPane.add(txtnic_1);
		
		txtappdate = new JTextField();
		txtappdate.setColumns(10);
		txtappdate.setBounds(1060, 280, 170, 20);
		contentPane.add(txtappdate);
		
		JButton btnAdd_1 = new JButton("Insert");
		btnAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtnic_1.getText();
				String app = txtappdate.getText();
				
				if(txtnic_1.getText().equals("") || txtappdate.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please fill all fields");
				}
				else {
					row1[0] = txtnic_1.getText();
					row1[1] = txtappdate.getText();
					
					model.addRow(row1);

					Admin ad = new Admin();
					ad.scheduleAppointment(nic, app);
					
					txtnic_1.setText("");
					txtappdate.setText("");
				}	
			}
		});
		btnAdd_1.setBounds(620, 366, 89, 23);
		contentPane.add(btnAdd_1);
		
		JButton btnupdate_1 = new JButton("Update");
		btnupdate_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtnic_1.getText();
				String app = txtappdate.getText();
				
				Admin ad = new Admin();
				ad.updateAppointment(nic, app);
				
				int i = table_2.getSelectedRow();
				if (i>=0) {
					model.setValueAt(txtnic_1.getText(), i, 0);
					model.setValueAt(txtappdate.getText(), i, 1);
				}
			}
		});
		btnupdate_1.setBounds(720, 366, 89, 23);
		contentPane.add(btnupdate_1);
		
		JButton btnsave_1 = new JButton("View");
		btnsave_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DatabaseConnection dbCon = new DatabaseConnection();
				Connection conn = dbCon.createConnection();
				
				DefaultTableModel model = new DefaultTableModel();
			    try {
			        String sql = "SELECT * FROM AppointmentDetails"; 
			        PreparedStatement pstmt = conn.prepareStatement(sql);
			        ResultSet rs = pstmt.executeQuery();

			        // Get metadata about the ResultSet (columns)
			        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
			        int columnCount = metaData.getColumnCount();

			        // Add columns to the table model
			        for (int column = 1; column <= columnCount; column++) {
			            model.addColumn(metaData.getColumnLabel(column));
			        }

			        // Add rows to the table model
			        while (rs.next()) {
			            Object[] row = new Object[columnCount];
			            for (int i = 0; i < columnCount; i++) {
			                row[i] = rs.getObject(i + 1);
			            }
			            model.addRow(row);
			        }
			
			        rs.close();
			        pstmt.close();
			        conn.close();
			        
			        // Set the model to the table
			        table_2.setModel(model);
			    
			  } 
			    catch (SQLException ex) {
			        ex.printStackTrace();	
			    }
			}
		});
		btnsave_1.setBounds(830, 366, 89, 23);
		contentPane.add(btnsave_1);
	}
}
