package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import java.awt.Point;
import java.awt.Font;

public class Register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtnic;
	private JPasswordField txtpassword;
	private JPasswordField txtconfirmpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
					//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
 			    } catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setLocation(new Point(600, 100));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 450, 300);
		//setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblnic = new JLabel("NIC");
		lblnic.setBounds(78, 82, 65, 14);
		contentPane.add(lblnic);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setBounds(78, 107, 89, 14);
		contentPane.add(lblpassword);
		
		txtnic = new JTextField();
		txtnic.setBounds(229, 76, 112, 20);
		contentPane.add(txtnic);
		txtnic.setColumns(10);
		
		JButton btnsignup = new JButton("Sign Up");
		btnsignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtnic.getText();
				String password = txtpassword.getText();
				String confirmPassword = txtconfirmpassword.getText();
				
				 if (!password.equals(confirmPassword)) {
				        JOptionPane.showMessageDialog(null, "Password and confirm password do not match!", "Password Mismatch", JOptionPane.ERROR_MESSAGE);
				        return; // Exit the method if passwords do not match
				    }
				 
				Verification verify = new Verification();
				verify.isDuplicateNIC(nic, password);
				
				boolean isValidCitizen = false;
				
				if(isValidCitizen == true) {
					ApplicantDashboard appDashboardFrame = new ApplicantDashboard();
					appDashboardFrame.setVisible(true);
					dispose();
				}
			}
		});
		btnsignup.setBounds(78, 177, 89, 23);
		contentPane.add(btnsignup);
		
		JButton btnback = new JButton("Back");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ApplicantLogin applicantLoginFrame = new ApplicantLogin();
				applicantLoginFrame.setVisible(true);
				dispose();
			}
		});
		btnback.setBounds(252, 177, 89, 23);
		contentPane.add(btnback);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(229, 104, 112, 20);
		contentPane.add(txtpassword);
		
		JLabel lblconfirmpassword = new JLabel("Confirm Password");
		lblconfirmpassword.setBounds(78, 132, 117, 14);
		contentPane.add(lblconfirmpassword);
		
		txtconfirmpassword = new JPasswordField();
		txtconfirmpassword.setBounds(229, 129, 112, 20);
		contentPane.add(txtconfirmpassword);
		
		JLabel lblSignUp = new JLabel("Sign Up");
		lblSignUp.setFont(new Font("Tekton Pro Cond", Font.BOLD, 30));
		lblSignUp.setBounds(165, 26, 122, 39);
		contentPane.add(lblSignUp);
	}
}
