package pas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Verification {
	
	Connection conn = null;
	Connection conn2 = null;
	String username = null;
	String password = null;
	

	public boolean isDuplicateNIC(String username, String password) {
		
		DatabaseConnection dbCon = new DatabaseConnection();
		conn = dbCon.createConnection();
		
		try {
			String sql = "SELECT aplNic FROM loginandsignup WHERE aplNic = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, username);
			ResultSet result = pstmt.executeQuery();
			
		if(result.next()) {
				JOptionPane.showMessageDialog(null, "You're already registered!");
				pstmt.close();
				conn.close();
			}else {
				isValidCitizen(username,password);
			}
			return true;
		}
        catch (SQLException e){
        	JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
         }
		return false;
    }
	
	
	public boolean isValidCitizen(String username, String password) {
		DatabaseConnection dbCon = new DatabaseConnection();
		Connection conn2 = dbCon.createConnection2();
		
		Applicant ap = new Applicant(username, password);
		
		try {
			String sql = "SELECT nic FROM citizendetails WHERE nic = ?";
	        PreparedStatement stmt = conn2.prepareStatement(sql);
	        stmt.setString(1, username);
	        ResultSet result = stmt.executeQuery();
	        
	        if (result.next()) {
	            result.getString("nic");
	           
	            JOptionPane.showMessageDialog(null, "Verification successful");
	            ap.signUpApplicant(username, password); 
	            
	        return true;
	           
	        } else {
	            // Verification failed, user is not a citizen of Sri Lanka
	            JOptionPane.showMessageDialog(null, "Not a citizen of Sri Lanka");
	        }  
		}
        catch (SQLException e){
        	JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
         }
		return false;
	}
	
	
	public boolean validateLogin(String username, String password) {
		DatabaseConnection dbcon = new DatabaseConnection();
		conn = dbcon.createConnection();
		
		try {
			String sql = "SELECT * FROM loginandsignup WHERE aplNic = ? AND aplPassword = ?";
	        
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	        pstatement.setString(1, username);
	        pstatement.setString(2, password);
	        
	        ResultSet resultSet = pstatement.executeQuery();
	        
	        if (resultSet.next()) {
	            String storedPassword = resultSet.getString("aplPassword");

	            if (storedPassword.equals(password)) {
	                JOptionPane.showMessageDialog(null, "Login Successful");
	            } 
	            return true;
	        } 
	        else {
	            JOptionPane.showMessageDialog(null, "Incorrect Username or Password");
	        }
		}
		catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
		}
		return false;
    }	
	
	public boolean validateAdminLogin(String username, String password) {
		DatabaseConnection dbcon = new DatabaseConnection();
		conn = dbcon.createConnection();
		
		try {
			String sql = "SELECT * FROM AdminLogin WHERE adminUsername = ? AND adminPassword = ?";
	        
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	        pstatement.setString(1, username);
	        pstatement.setString(2, password);
	        
	        ResultSet resultSet = pstatement.executeQuery();
	        
	        if (resultSet.next()) {
	            String storedPassword = resultSet.getString("adminPassword");

	            if (storedPassword.equals(password)) {
	                JOptionPane.showMessageDialog(null, "Login Successful");
	            } 
	            return true;
	        } 
	        else {
	            JOptionPane.showMessageDialog(null, "Incorrect Username or Password");
	        }
		}
		catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
		}
		return false;
    }	
}

