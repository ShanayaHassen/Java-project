package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class ViewStatus extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtenternic;
	private JLabel lblStatus;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewStatus frame = new ViewStatus();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewStatus() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblenternic = new JLabel("Enter NIC");
		lblenternic.setBounds(84, 100, 80, 20);
		contentPane.add(lblenternic);
		
		txtenternic = new JTextField();
		txtenternic.setBounds(195, 100, 130, 20);
		contentPane.add(txtenternic);
		txtenternic.setColumns(10);
		
		JButton btnview = new JButton("View");
		btnview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String enterednic = txtenternic.getText();
				
				Applicant ap = new Applicant();
				ap.viewStatus(enterednic);
			}
		});
		btnview.setBounds(159, 149, 89, 23);
		contentPane.add(btnview);
		
		lblStatus = new JLabel("Status");
		lblStatus.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblStatus.setBounds(10, 11, 167, 34);
		contentPane.add(lblStatus);
	}
}
