package pas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Admin {
	Connection conn;
	private String aplNic;
	private String aplStatus;
	
	public Admin() {}
	
	public void insertStatus(String aplNic,String aplStatus) {
		
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	        String sql = "INSERT INTO ApplicantStatus (aplNic, aplStatus) VALUES (?,?)";
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	       
	        pstatement.setString(1, aplNic);
	        pstatement.setString(2, aplStatus);
	      
	        int rowsInserted = pstatement.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Data inserted successfully");
	        } else {
	            JOptionPane.showMessageDialog(null, "Data insertion failed");
	        }
	    } 
    	catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
	
	public void updateStatus(String aplNic,String aplStatus) {
		
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	    	String sql = "UPDATE ApplicantStatus SET aplStatus = ? WHERE aplNic = ?";
	    	PreparedStatement pstatement = conn.prepareStatement(sql);
	    	
	    	pstatement.setString(1, aplStatus);
	    	pstatement.setString(2, aplNic); 
	    	
	    	int rowsUpdated = pstatement.executeUpdate();
	    	if (rowsUpdated > 0) {
	    		JOptionPane.showMessageDialog(null, "Data updated successfully!");
	    	} 
	    	else {
	    		JOptionPane.showMessageDialog(null, "Data update Failed!");
	    	}
	    }
	    catch(SQLException e) {
	    	JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
	
    public void scheduleAppointment(String aplNic, String aplAppointment) {
    	DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	        String sql = "INSERT INTO AppointmentDetails (aplNic, aplAppointment) VALUES (?,?)";
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	        
	        pstatement.setString(1, aplNic);
	        pstatement.setString(2, aplAppointment);
	      
	        int rowsInserted = pstatement.executeUpdate();
	        
	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Data inserted successfully");
	        } else {
	            JOptionPane.showMessageDialog(null, "Data insertion failed");
	        }
	    } 
    	catch (SQLException e) {
    		JOptionPane.showMessageDialog(null, e.getMessage());
	    }
    }
    
    public void updateAppointment(String aplNic, String aplAppointment) {
		
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	    	String sql = "UPDATE AppointmentDetails SET aplAppointment = ? WHERE aplNic = ?";
	    	PreparedStatement pstatement = conn.prepareStatement(sql);
	    	
	    	pstatement.setString(1, aplAppointment);
	    	pstatement.setString(2, aplNic); 
	    	
	    	int rowsUpdated = pstatement.executeUpdate();
	    	if (rowsUpdated > 0) {
	    		JOptionPane.showMessageDialog(null, "Data updated successfully!");
	    	} 
	    	else {
	    		JOptionPane.showMessageDialog(null, "Data update Failed!");
	    	}
	    }
	    catch(SQLException e) {
	    	JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
}
