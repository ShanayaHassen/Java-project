package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class MakeAppointment extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtenternic;
	private JTextField txtselecteddate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MakeAppointment frame = new MakeAppointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MakeAppointment() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 478, 302);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btndates = new JButton("Check Available Dates");
		btndates.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtenternic.getText();
				
				Applicant ap = new Applicant();
				ap.checkAvailableDates(nic);
			}
		});
		btndates.setBounds(294, 87, 160, 23);
		contentPane.add(btndates);
		
		JLabel lblenternic = new JLabel("Enter NIC");
		lblenternic.setBounds(26, 88, 60, 20);
		contentPane.add(lblenternic);
		
		txtenternic = new JTextField();
		txtenternic.setColumns(10);
		txtenternic.setBounds(96, 88, 188, 20);
		contentPane.add(txtenternic);
		
		JLabel lblselecteddate = new JLabel("Enter Selected \r\nDate");
		lblselecteddate.setBounds(26, 138, 119, 14);
		contentPane.add(lblselecteddate);
		
		txtselecteddate = new JTextField();
		txtselecteddate.setColumns(10);
		txtselecteddate.setBounds(144, 135, 141, 20);
		contentPane.add(txtselecteddate);
		
		JButton btnmakeapp = new JButton("Make Appointment");
		btnmakeapp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nic = txtenternic.getText();
				String date = txtselecteddate.getText();
				
				Applicant ap = new Applicant();
				ap.updateAppointment(nic,date);
			}
		});
		btnmakeapp.setBounds(294, 134, 158, 23);
		contentPane.add(btnmakeapp);
		
		JLabel lblAppointment = new JLabel("Appointments");
		lblAppointment.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblAppointment.setBounds(10, 11, 274, 34);
		contentPane.add(lblAppointment);
	}

}
