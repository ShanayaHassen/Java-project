package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class GenerateReport extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtenterednic;
	private JLabel lblNic;
	private JLabel lblFirstName;
	private JLabel lblLastName;
	private JLabel lblDob_1;
	private JLabel lblContactNo;
	private JLabel lblEmail_1;
	private JLabel lblAddress_1;
	private JLabel lblGender_1;
	private JLabel lblOccupation;
	private JTextField txtnic;
	private JTextField txtfirstname;
	private JTextField txtlastname;
	private JTextField txtdob;
	private JTextField txtcontact;
	private JTextField txtemail;
	private JTextField txtaddress;
	private JTextField txtgender;
	private JTextField txtoccupation;
	private JLabel lblReport;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GenerateReport frame = new GenerateReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GenerateReport() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 597, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnShow = new JButton("Show");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DatabaseConnection dbcon = new DatabaseConnection();
			    Connection conn = dbcon.createConnection();
			    
			    try {
			        String sql = "SELECT aplNic, aplFirstName, aplLastName, aplDOB, aplContact, aplEmail, aplAddress, aplGender, aplOccupation FROM Applicant WHERE aplNic = ?";
			        
			        String nic = txtenterednic.getText();
			        
			        PreparedStatement pstmt = conn.prepareStatement(sql);
			        pstmt.setString(1, nic);
			        ResultSet resultSet = pstmt.executeQuery();
			        
			        if (!resultSet.next()) {
			            JOptionPane.showMessageDialog(null, "NIC not found");
			        } 
			        else {
			            String NIC = resultSet.getString(1);
			            String firstName = resultSet.getString(2);
			            String lastName = resultSet.getString(3);
			            String dob = resultSet.getString(4);
			            String contact = resultSet.getString(5);
			            String email = resultSet.getString(6);
			            String address = resultSet.getString(7);
			            String gender = resultSet.getString(8);
			            String occupation = resultSet.getString(9);
			            
			            txtnic.setText(NIC);
			            txtfirstname.setText(firstName);
			            txtlastname.setText(lastName);
			            txtdob.setText(dob);
			            txtcontact.setText(contact);
			            txtemail.setText(email);
			            txtaddress.setText(address);
			            txtgender.setText(gender);
			            txtoccupation.setText(occupation);
			            
			            txtnic.setEnabled(false);
			            txtfirstname.setEnabled(false);
			            txtlastname.setEnabled(false);
			            txtdob.setEnabled(false);
			            txtcontact.setEnabled(false);
			            txtemail.setEnabled(false);
			            txtaddress.setEnabled(false);
			            txtgender.setEnabled(false);
			            txtoccupation.setEnabled(false);
			        }
			    }
			    catch(SQLException ex) {
			    	JOptionPane.showMessageDialog(null, ex.getMessage());
			    }
			}
		});
		btnShow.setBounds(357, 78, 89, 23);
		contentPane.add(btnShow);
		
		JLabel lblnic = new JLabel("Enter NIC:");
		lblnic.setBounds(43, 82, 89, 14);
		contentPane.add(lblnic);
		
		txtenterednic = new JTextField();
		txtenterednic.setBounds(164, 79, 140, 20);
		contentPane.add(txtenterednic);
		txtenterednic.setColumns(10);
		
		lblNic = new JLabel("NIC ");
		lblNic.setBounds(43, 146, 46, 14);
		contentPane.add(lblNic);
		
		lblFirstName = new JLabel("First Name ");
		lblFirstName.setBounds(43, 179, 73, 14);
		contentPane.add(lblFirstName);
		
		lblLastName = new JLabel("Last Name ");
		lblLastName.setBounds(43, 210, 73, 14);
		contentPane.add(lblLastName);
		
		lblDob_1 = new JLabel("DOB ");
		lblDob_1.setBounds(43, 240, 62, 14);
		contentPane.add(lblDob_1);
		
		lblContactNo = new JLabel("Contact No. ");
		lblContactNo.setBounds(43, 270, 73, 14);
		contentPane.add(lblContactNo);
		
		lblEmail_1 = new JLabel("E-mail ");
		lblEmail_1.setBounds(43, 300, 62, 14);
		contentPane.add(lblEmail_1);
		
		lblAddress_1 = new JLabel("Address ");
		lblAddress_1.setBounds(43, 335, 62, 14);
		contentPane.add(lblAddress_1);
		
		lblGender_1 = new JLabel("Gender ");
		lblGender_1.setBounds(280, 146, 62, 14);
		contentPane.add(lblGender_1);
		
		lblOccupation = new JLabel("Occupation ");
		lblOccupation.setBounds(280, 179, 86, 14);
		contentPane.add(lblOccupation);
		
		txtnic = new JTextField();
		txtnic.setColumns(10);
		txtnic.setBounds(118, 143, 140, 20);
		contentPane.add(txtnic);
		
		txtfirstname = new JTextField();
		txtfirstname.setColumns(10);
		txtfirstname.setBounds(118, 176, 140, 20);
		contentPane.add(txtfirstname);
		
		txtlastname = new JTextField();
		txtlastname.setColumns(10);
		txtlastname.setBounds(118, 207, 140, 20);
		contentPane.add(txtlastname);
		
		txtdob = new JTextField();
		txtdob.setColumns(10);
		txtdob.setBounds(118, 237, 140, 20);
		contentPane.add(txtdob);
		
		txtcontact = new JTextField();
		txtcontact.setColumns(10);
		txtcontact.setBounds(118, 267, 140, 20);
		contentPane.add(txtcontact);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(118, 297, 140, 20);
		contentPane.add(txtemail);
		
		txtaddress = new JTextField();
		txtaddress.setColumns(10);
		txtaddress.setBounds(118, 332, 140, 20);
		contentPane.add(txtaddress);
		
		txtgender = new JTextField();
		txtgender.setColumns(10);
		txtgender.setBounds(350, 143, 140, 20);
		contentPane.add(txtgender);
		
		txtoccupation = new JTextField();
		txtoccupation.setColumns(10);
		txtoccupation.setBounds(350, 176, 140, 20);
		contentPane.add(txtoccupation);
		
		lblReport = new JLabel("Report");
		lblReport.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblReport.setBounds(10, 11, 274, 34);
		contentPane.add(lblReport);
	}
}
