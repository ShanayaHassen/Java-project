package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ApplicantDashboard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicantDashboard frame = new ApplicantDashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ApplicantDashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnFillform = new JButton("Fill Form");
		btnFillform.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PassportApplication passportApplFrame = new PassportApplication();
				passportApplFrame.setVisible(true);
				dispose();
			}
		});
		btnFillform.setBounds(149, 69, 142, 23);
		contentPane.add(btnFillform);
		
		JButton btnViewstatus = new JButton("View Status");
		btnViewstatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ViewStatus vs = new ViewStatus();
				vs.setVisible(true);
				dispose();
			}
		});
		btnViewstatus.setBounds(149, 103, 142, 23);
		contentPane.add(btnViewstatus);
		
		JButton btnMakeAppointment = new JButton("Make Appointment");
		btnMakeAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MakeAppointment ma = new MakeAppointment();
				ma.setVisible(true);
				dispose();
			}
		});
		btnMakeAppointment.setBounds(149, 137, 142, 23);
		contentPane.add(btnMakeAppointment);
		
		JLabel lblHelloThere = new JLabel("Dashboard");
		lblHelloThere.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblHelloThere.setBounds(10, 24, 167, 34);
		contentPane.add(lblHelloThere);
		
		JButton btnGenerateReport = new JButton("Generate Report");
		btnGenerateReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GenerateReport genrep = new GenerateReport();
				genrep.setVisible(true);
				dispose();
			}
		});
		btnGenerateReport.setBounds(149, 174, 142, 23);
		contentPane.add(btnGenerateReport);
	}
}
