package pas;

import java.io.ByteArrayOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class Applicant {
	private Connection conn;
	private String aplNic;
	private String aplPassword;
	private String aplFirstName;
	private String aplLastName;
	private String aplEmail;
	private String aplContact;
	private String aplGender;
	private String aplDOB;
	private String aplAddress;
	private String aplOccupation;
	private String aplPasPhoto;
	private Blob aplNicBc;
	private ByteArrayOutputStream baos;;
	
	public Applicant() {}
	
	public Applicant(String aplNic, String aplFirstName, String aplLastName, String aplDOB, String aplContact, String aplEmail, String aplAddress, String aplGender,String aplOccupation) {
		this.aplNic = aplNic;
		this.aplFirstName = aplFirstName;
		this.aplLastName = aplLastName;
		this.aplDOB = aplDOB;
		this.aplContact = aplContact;
		this.aplEmail = aplEmail;
		this.aplAddress = aplAddress;
		this.aplGender = aplGender;
		this.aplOccupation = aplOccupation;
	}
	
	
	public Applicant(String aplNic,String aplPassword) {
		this.aplNic = aplNic;
		this.aplPassword = aplPassword;
	}

	public void signUpApplicant(String aplNic, String aplPassword) {
		
		DatabaseConnection dbCon = new DatabaseConnection();
		conn = dbCon.createConnection();
		
	    	try {
		        String sql = "INSERT INTO LoginAndSignup (aplNic, aplPassword) VALUES (?,?)";
		        PreparedStatement pstatement = conn.prepareStatement(sql);
		        
		        pstatement.setString(1, aplNic);
		        pstatement.setString(2, aplPassword);
		      
		        int rowsInserted = pstatement.executeUpdate();
		        
		        if (rowsInserted > 0) {
		            JOptionPane.showMessageDialog(null, "Data inserted successfully");
		        } else {
		            JOptionPane.showMessageDialog(null, "Data insertion failed");
		        }
		    } 
	    	catch (SQLException e) {
		        System.out.println("Error: " + e.getMessage());
		    }
	  }
	
	
	public void submitApplication() {
		
		DatabaseConnection dbCon = new DatabaseConnection();
		conn = dbCon.createConnection();
		
		try {
	    	String sql = "INSERT INTO Applicant (aplNic, aplFirstName, aplLastName, aplDOB, aplContact, aplEmail, aplAddress, aplGender, aplOccupation) VALUES (?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt = conn.prepareStatement(sql);
	        
	        pstmt.setString(1, aplNic);
	        pstmt.setString(2, aplFirstName);
	        pstmt.setString(3, aplLastName);
	        pstmt.setString(4, aplDOB);
	        pstmt.setString(5, aplContact);
	        pstmt.setString(6, aplEmail);
	        pstmt.setString(7, aplAddress);
	        pstmt.setString(8, aplGender);
	        pstmt.setString(9, aplOccupation);
              
	        int rowsInserted = pstmt.executeUpdate();
	       
	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Data inserted successfully");
	        } else {
	            JOptionPane.showMessageDialog(null, "Data insertion failed");
	        }
	    }
	    catch(SQLException e) {
	    	System.out.println("Error: " + e.getMessage());
	    }
	}
	
	public void uploadDocs(byte[] documentBytes) {
	    DatabaseConnection dbCon = new DatabaseConnection();
	    conn = dbCon.createConnection();

	    try {
	        String sql = "INSERT INTO Applicant (aplNicBc) VALUES (?)";
	        PreparedStatement pstmt = conn.prepareStatement(sql);

	        // Set the byte array directly to the Blob column
	        pstmt.setBytes(1, documentBytes);

	        int rowsInserted = pstmt.executeUpdate();

	        if (rowsInserted > 0) {
	            JOptionPane.showMessageDialog(null, "Uploaded successfully");
	        } else {
	            JOptionPane.showMessageDialog(null, "Uploading failed");
	        }
	    } catch (SQLException e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}

	private void insertImage(byte[] imageData) {
        try {
            String sql = "INSERT INTO Images (image_data) VALUES (?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setBytes(1, imageData);

            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Image uploaded successfully.");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to upload image.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
	
	public void viewStatus(String aplNic){
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	    	String sql = "SELECT aplStatus FROM applicantStatus WHERE aplNic = ?";
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	        pstatement.setString(1, aplNic);
	        ResultSet resultSet = pstatement.executeQuery();
	        while (resultSet.next()) {
	        	 String status = resultSet.getString("aplStatus");
	        	 
	        	 JOptionPane.showMessageDialog(null, "Your status is: "+ status);
	        	}
	    }
	    catch(SQLException e) {
	    	JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
	
	public void checkAvailableDates(String aplNic){
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	    	String sql = "SELECT aplAppointment FROM AppointmentDetails WHERE aplNic = ?";
	        PreparedStatement pstatement = conn.prepareStatement(sql);
	        pstatement.setString(1, aplNic);
	        ResultSet resultSet = pstatement.executeQuery();
	        while (resultSet.next()) {
	        	 String appointment = resultSet.getString("aplAppointment");
	        	 
	        	 JOptionPane.showMessageDialog(null, "Available Dates: "+ appointment);
	        	}
	    }
	    catch(SQLException e) {
	    	JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
	
	public void updateAppointment(String aplNic, String aplAppointment) {
		
		DatabaseConnection dbcon = new DatabaseConnection();
	    Connection conn = dbcon.createConnection(); 
	    
	    try {
	    	String sql = "UPDATE AppointmentDetails SET aplAppointment = ? WHERE aplNic = ?";
	    	PreparedStatement pstatement = conn.prepareStatement(sql);
	    	
	    	pstatement.setString(1, aplAppointment);
	    	pstatement.setString(2, aplNic); 
	    	
	    	int rowsUpdated = pstatement.executeUpdate();
	    	if (rowsUpdated > 0) {
	    		JOptionPane.showMessageDialog(null, "Date reserved successfully!");
	    	} 
	    	else {
	    		JOptionPane.showMessageDialog(null, "Date reservation Failed!");
	    	}
	    }
	    catch(SQLException e) {
	    	JOptionPane.showMessageDialog(null, e.getMessage());
	    }
	}
	
}
