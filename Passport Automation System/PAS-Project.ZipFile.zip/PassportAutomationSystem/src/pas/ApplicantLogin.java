package pas;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ApplicantLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtusername;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApplicantLogin frame = new ApplicantLogin();
					frame.setVisible(true);
					//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ApplicantLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtusername = new JTextField();
		txtusername.setBounds(174, 76, 175, 20);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		JButton btnlogin = new JButton("Log In\r\n");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String username = txtusername.getText();
				String password = txtpassword.getText();
				
				Verification verify = new Verification();
				boolean isValidLogin = verify.validateLogin(username, password);
		        
				if (isValidLogin) {
	                dispose();
	                ApplicantDashboard appDashboardFrame = new ApplicantDashboard();
			        appDashboardFrame.setVisible(true);
	            } 
			}
		});
		btnlogin.setBounds(64, 167, 89, 23);
		contentPane.add(btnlogin);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(174, 107, 175, 20);
		contentPane.add(txtpassword);
		
		JLabel lblusername = new JLabel("Username");
		lblusername.setBounds(27, 79, 80, 14);
		contentPane.add(lblusername);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setBounds(27, 113, 80, 14);
		contentPane.add(lblpassword);
		
		JLabel lblNewLabel = new JLabel("Welcome Back");
		lblNewLabel.setFont(new Font("Tekton Pro Cond", Font.BOLD, 30));
		lblNewLabel.setBounds(144, 24, 168, 39);
		contentPane.add(lblNewLabel);
		
		JButton btnback = new JButton("Back");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				HomePage HomePageFrame = new HomePage();
				HomePageFrame.setVisible(true);
				dispose();
			}
		});
		btnback.setBounds(248, 167, 89, 23);
		contentPane.add(btnback);
		
		JLabel lblNewLabel_1 = new JLabel("Don't have an account?");
		lblNewLabel_1.setBounds(158, 204, 150, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Register register = new Register();
				register.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(158, 227, 89, 23);
		contentPane.add(btnNewButton);
	}
}
