package pas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtusername;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome Back");
		lblNewLabel.setBounds(152, 23, 141, 37);
		lblNewLabel.setFont(new Font("Tekton Pro Cond", Font.BOLD, 30));
		contentPane.add(lblNewLabel);
		
		JLabel lblusername = new JLabel("Username");
		lblusername.setBounds(59, 90, 80, 14);
		contentPane.add(lblusername);
		
		JLabel lblpassword = new JLabel("Password");
		lblpassword.setBounds(59, 130, 80, 14);
		contentPane.add(lblpassword);
		
		txtusername = new JTextField();
		txtusername.setColumns(10);
		txtusername.setBounds(189, 87, 175, 20);
		contentPane.add(txtusername);
		
		txtpassword = new JPasswordField();
		txtpassword.setBounds(189, 127, 175, 20);
		contentPane.add(txtpassword);
		
		JButton btnlogin = new JButton("Log In\r\n");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String username = txtusername.getText();
				String password = txtpassword.getText();
				
				Verification verify = new Verification();
				boolean isValidLogin = verify.validateAdminLogin(username, password);
		        
				if (isValidLogin) {
	                dispose();
	                AdminPanel adpanel = new AdminPanel();
	                adpanel.setVisible(true);
	            } 
			}
		});
		btnlogin.setBounds(80, 193, 89, 23);
		contentPane.add(btnlogin);
		
		JButton btnback = new JButton("Back");
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				HomePage HomePageFrame = new HomePage();
				HomePageFrame.setVisible(true);
				dispose();
			}
		});
		btnback.setBounds(273, 193, 89, 23);
		contentPane.add(btnback);
	}
}
