/**
 * 
 */
/**
 * 
 */
module PassportAutomationSystem {
	requires java.desktop;
	requires java.sql;
}